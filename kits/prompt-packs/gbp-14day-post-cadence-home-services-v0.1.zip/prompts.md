# GBP 14-Day Post Cadence — Home Services Prompts

Fill placeholders with **true** business facts. If unknown, keep the placeholder — do not invent.

---

## Prompt 0 — System: GBP copy helper

```text
You write Google Business Profile posts and Q&A drafts for home-services businesses (HVAC, plumbing, electrical, locksmith, garage door, landscaping, handyman, cleaning).

Hard rules:
- Never invent licenses, insurance, prices, ETAs, warranties, financing, or service-area claims.
- Use {{placeholders}} when a fact is missing.
- No fake reviews, fake customers, fake UGC, or fabricated Q&A “from customers.”
- No keyword stuffing; answer plainly; prefer short paragraphs.
- No ranking guarantees, “#1 in town,” or income/lead-volume promises.
- Review-ask language must be optional and must not condition service on a review or incentivize 5-stars.
- For emergencies: remind readers that life-threatening situations need emergency services first.
- Flag any line that needs owner legal/policy approval with [OWNER CHECK].
- Default tone: competent, neighborly, specific, not hypey.
- Cadence honesty: if daily posting is unrealistic, say so and suggest a sustainable subset.
```

---

## Prompt 1 — Business intake

```text
Build a fact sheet I will reuse for GBP posts and Q&A.

Business name: {{business_name}}
Trade: {{trade}}
Service area: {{service_area}}
Phone: {{phone}}
Booking URL (if any): {{booking_url}}
Hours: {{hours}}
Same-day?: {{policy_or_unknown}}
After-hours?: {{policy_or_unknown}}
Estimate process: {{policy_or_unknown}}
Payment methods: {{list_or_unknown}}
License/insurance statement allowed to publish: {{exact_text_or_unknown}}
Seasonal focus this period: {{seasonal}}
Offers we may mention (only if real): {{offers_or_none}}
Words we never use (brand voice bans): {{bans}}
Owner voice notes (short/long, formal/casual): {{voice}}
Realistic post frequency: {{daily_or_3x_week_or_other}}

Output a compact FACT SHEET markdown. Mark unknowns as {{placeholder}}. Do not invent facts.
```

---

## Prompt 2 — Full 14-day batch (primary)

```text
Using the FACT SHEET below, draft 14 GBP posts (Day 1–14). Each post:
- 400–900 characters preferred (ok to note if longer)
- 1 clear next step (call / book / reply)
- 3–5 optional photo ideas (no stock-photo claims)
- 1 line CTA without pressure
- [OWNER CHECK] tags where needed

Day themes (home services):
1) Clear introduction — what we do in {{service_area}}
2) One useful prevention tip
3) Explain a service (what’s included / first step)
4) Hours and response expectations (honest)
5) A bounded offer (only if real; else skip with note)
6) Work-quality / visit checklist signal (no fake awards)
7) Seasonal readiness for {{seasonal}}
8) Answer a common question (FAQ-style post)
9) Maintenance reminder (safe; no universal interval invention)
10) Meet the people or process (permission required for names/photos)
11) Service-area clarity (self-qualify; no fake doorways)
12) Customer preparation checklist before a visit
13) Community OR hiring update (only if true — pick one)
14) Recap + practical next step (no scarcity theater)

FACT SHEET:
{{paste_fact_sheet}}

Also: (a) list 5 topics to avoid, (b) if realistic frequency is not daily, propose which 7 of 14 to publish first.
```

---

## Prompt 3 — Day-by-day expander

```text
Expand Day {{n}} only, using the FACT SHEET and theme: {{theme}}.

Requirements: true facts only, placeholders for unknowns, [OWNER CHECK] where needed, photo ideas that belong to the business, no ranking claims.

FACT SHEET:
{{paste_fact_sheet}}
```

---

## Prompt 4 — Q&A bank (12 starters)

```text
Draft 12 Google Business Profile Q&A pairs for {{trade}} in {{service_area}}.

Rules:
- Questions must be realistic pre-sale questions — labeled as DRAFT, not as real customer quotes.
- Answers use placeholders for unknown policies.
- No fake reviews, no “we’re #1,” no invented licenses.
- Include at least one emergency/safety redirect where relevant.
- Tag [OWNER CHECK] on anything legal/price/ETA related.

FACT SHEET:
{{paste_fact_sheet}}
```

---

## Prompt 5 — Warm review-ask (ethical)

```text
Draft a short GBP post that invites feedback only from customers who already had a real visit.

Hard bans: no discounts for 5-stars, no “review to unlock,” no filtering negative feedback instructions.
Include how to contact {{business_name}} if something went wrong (phone/email placeholders).

FACT SHEET:
{{paste_fact_sheet}}
```

---

## Prompt 6 — Rewrite for voice

```text
Rewrite the draft below in our voice notes: {{voice}}
Keep all facts; keep placeholders; remove hype and ranking claims.

DRAFT:
{{draft}}
```

---

## Prompt 7 — Shorten for mobile

```text
Shorten this GBP post to ≤ {{max_chars}} characters. Keep the CTA and one concrete detail. No new claims.

DRAFT:
{{draft}}
```

---

## Prompt 8 — Owner approval checklist

```text
Produce an owner approval checklist for the 14 drafts (or the subset we selected).

For each post: facts verified? offer real? photos owned/permitted? [OWNER CHECK] resolved? emergency language OK?
Output a markdown table. Do not invent that items were verified.
```

---

## Prompt 9 — Reuse loop (after day 14)

```text
Based on what actually happened (calls, messages, booked jobs, real questions asked), propose which 2 posts to rewrite for the next cycle.

Inputs:
{{what_happened}}

Rules: no copy-paste scarcity; no fake social proof; suggest new photo or example only if we have one.
```

---
*Not affiliated with Google · no ranking/income guarantees · Passive Engine v0.1*
