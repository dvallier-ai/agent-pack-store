# PromptBase listing — GBP 14-Day Post Cadence Prompt Pack (Home Services)

| Field | Value |
|-------|-------|
| **Title** | GBP 14-Day Post Cadence Prompt Pack (Home Services) |
| **SKU** | `prompt-gbp-14day-home-services-v0.1` |
| **PromptBase price** | **$7.99** |
| **BTC zip price** | **$7.99** (pay-btc companion) |
| **Category** | Marketing / Local SEO / Small Business |
| **Model tags** | ChatGPT, Claude, Gemini, GPT-4o |
| **File in zip** | `prompts.md` + `README.md` |

## Short description (PromptBase)

Generate a **14-day Google Business Profile** post cadence plus a compliant **Q&A bank** for home services (HVAC, plumbing, electrical, locksmith, garage door, landscaping). Placeholders for real policies — no fake reviews, no keyword stuffing, no income claims. Publish daily only if realistic; otherwise treat as fourteen prompts at a sustainable pace.

## Preview-safe blurb (safe to show unpaid)

> Need two weeks of GBP posts that sound like a real home-services shop — not AI sludge? This pack walks ChatGPT/Claude through: business intake → 14 post drafts (intro, tips, seasonal, FAQ, community/hiring, recap) → Q&A bank with honesty guards → publish checklist.
>
> Tuned for locksmith / plumber / HVAC-class businesses. Preview = day themes list. Paid = full prompt chain + README.

## What’s included (paid)

- System prompt: local GBP copy helper (compliance-aware)
- Business intake prompt
- Full 14-day batch generator + day-theme list
- Q&A bank generator with policy placeholders
- Review-ask language that stays warm/ethical
- Rewrite-for-voice + shorten-for-mobile + owner approval checklist

## What this is not

- Not affiliated with Google
- Not a ranking guarantee or “#1 on Maps” promise
- Not fake customer questions, fake reviews, or review gating instructions

## Suggested PromptBase keywords

`google business profile`, `GBP`, `local seo`, `home services`, `HVAC`, `plumber`, `locksmith`, `content calendar`, `small business marketing`
