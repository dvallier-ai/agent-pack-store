# GBP 14-Day Post Cadence Prompt Pack (Home Services) v0.1

**SKU:** `prompt-gbp-14day-home-services-v0.1`  
**PromptBase:** $7.99 · **BTC/ETH:** $7.99

Educational prompts for drafting a **14-day** Google Business Profile cadence for home-services businesses.

## Honest cadence note

Use one post per day **only if that is realistic**. Otherwise treat the sequence as fourteen prompts and publish at a lower sustainable frequency. Never invent offers, licenses, ETAs, or reviews.

## How to use

1. Paste Prompt 0 (system) once.
2. Run intake → FACT SHEET.
3. Run the 14-day batch (or day-by-day).
4. Generate Q&A with placeholders for unknown policies.
5. Owner approval checklist before publish.

## What this is not

- Not affiliated with Google · No ranking/income guarantees · Not fake reviews

## Support

`dvallier@gmail.com` · SKU `prompt-gbp-14day-home-services-v0.1`

---
*Passive Engine · 2026-09-19 PT*
