# PromptBase listing — GBP 7-Day Post+Q&A Prompt Pack (Home Services)

| Field | Value |
|-------|-------|
| **Title** | GBP 7-Day Post+Q&A Prompt Pack (Home Services) |
| **SKU** | `prompt-gbp-7day-home-services-v0.1` |
| **PromptBase price** | **$6.99** |
| **BTC zip price** | **$7.99** (pay-btc companion) |
| **Category** | Marketing / Local SEO / Small Business |
| **Model tags** | ChatGPT, Claude, Gemini, GPT-4o |
| **File in zip** | `prompts.md` + `README.md` |

## Short description (PromptBase)

Generate a **7-day Google Business Profile** post cadence plus a compliant **Q&A bank** for home services (HVAC, plumbing, electrical, locksmith, garage door, landscaping). Placeholders for real policies — no fake reviews, no keyword stuffing, no income claims.

## Preview-safe blurb (safe to show unpaid)

> Need a week of GBP posts that sound like a real home-services shop — not AI sludge? This pack walks ChatGPT/Claude through: business intake → 7 post drafts (offer, how-to, seasonal, hiring/careers optional, community, FAQ teaser, review-ask *warm only*) → 12 Q&A pairs with honesty guards → a publish checklist.
>
> Tuned for locksmith / plumber / HVAC-class businesses. Preview = day themes list. Paid = full prompt chain + README.

## What’s included (paid)

- System prompt: local GBP copy helper (compliance-aware)  
- Business intake prompt  
- 7 day-by-day post generators + batch-week prompt  
- Q&A bank generator (12 starters) with policy placeholders  
- Review-ask language that stays warm/ethical (no incentives that violate Google rules)  
- Rewrite-for-voice + shorten-for-mobile prompts  
- Owner approval checklist prompt  

## What this is not

- Not affiliated with Google  
- Not a ranking guarantee or “#1 on Maps” promise  
- Not fake customer questions, fake reviews, or review gating instructions  

## Suggested PromptBase keywords

`google business profile`, `GBP`, `local seo`, `home services`, `HVAC`, `plumber`, `locksmith`, `small business marketing`
