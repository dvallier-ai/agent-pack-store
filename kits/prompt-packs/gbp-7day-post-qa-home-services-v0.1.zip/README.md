# GBP 7-Day Post+Q&A Prompt Pack (Home Services) — Buyer README

**Version:** 0.1.0 · **Seller:** Dan Vallier / Passive Engine · Agent Pack Store  
**Use with:** ChatGPT, Claude, Gemini  

## What you bought

A prompt chain that produces one week of Google Business Profile (GBP) posts and a starter Q&A bank for **home-services** businesses — with placeholders for real policies and explicit compliance guards.

## Recommended flow

1. Paste **Prompt 0** (system).  
2. Run **Prompt 1** (intake) with real business facts only.  
3. Run **Prompt 2** (full 7-day batch) *or* Prompts 3–9 one day at a time.  
4. Run **Prompt 10** for Q&A.  
5. Run **Prompt 11** to rewrite in the owner’s voice; **Prompt 12** to shorten.  
6. Run **Prompt 13** approval checklist with the owner before publishing.

## Compliance (read this)

- Do **not** invent licenses, warranties, prices, response times, or service areas.  
- Do **not** create fake customer questions or fake reviews.  
- Do **not** offer review incentives that violate Google’s policies; keep review-asks warm and optional.  
- Q&A answers must match written business policy — use `{{placeholders}}` until confirmed.  
- No “guaranteed ranking,” “dominate Maps,” or income claims in posts.

## Trades this pack fits

HVAC, plumbing, electrical, locksmith, garage door, handyman, landscaping, pest (adapt carefully), cleaning.  
If a trade has legal advertising restrictions in your area, follow those over any model output.

## License (buyer)

Use for your business or client businesses. Do not resell the pack as a prompt product.

## Support

SKU `prompt-gbp-7day-home-services-v0.1` · `dvallier@gmail.com` for crypto fulfill orders.
