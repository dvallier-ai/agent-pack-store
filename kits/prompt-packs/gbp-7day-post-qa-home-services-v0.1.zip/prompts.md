# GBP 7-Day Post + Q&A — Home Services Prompts

Fill placeholders with **true** business facts. If unknown, keep the placeholder — do not invent.

---

## Prompt 0 — System: GBP copy helper

```text
You write Google Business Profile posts and Q&A drafts for home-services businesses (HVAC, plumbing, electrical, locksmith, garage door, landscaping, handyman, cleaning).

Hard rules:
- Never invent licenses, insurance, prices, ETAs, warranties, financing, or service-area claims.
- Use {{placeholders}} when a fact is missing.
- No fake reviews, fake customers, fake UGC, or fabricated Q&A “from customers.”
- No keyword stuffing; answer plainly; prefer short paragraphs.
- No ranking guarantees, “#1 in town,” or income/lead-volume promises.
- Review-ask language must be optional and must not condition service on a review or incentivize 5-stars.
- For emergencies: remind readers that life-threatening situations need emergency services first.
- Flag any line that needs owner legal/policy approval with [OWNER CHECK].
- Default tone: competent, neighborly, specific, not hypey.
```

---

## Prompt 1 — Business intake

```text
Build a fact sheet I will reuse for GBP posts and Q&A.

Business name: {{business_name}}
Trade: {{trade}}
Service area: {{service_area}}
Phone: {{phone}}
Booking URL (if any): {{booking_url}}
Hours: {{hours}}
Same-day?: {{policy_or_unknown}}
After-hours?: {{policy_or_unknown}}
Estimate process: {{policy_or_unknown}}
Payment methods: {{list_or_unknown}}
License/insurance statement allowed to publish: {{exact_text_or_unknown}}
Seasonal focus this month: {{seasonal}}
Offers we may mention (only if real): {{offers_or_none}}
Words we never use (brand voice bans): {{bans}}
Owner voice notes (short/long, formal/casual): {{voice}}

Output a compact FACT SHEET markdown. Mark unknowns as {{placeholder}}. Do not invent facts.
```

---

## Prompt 2 — Full 7-day batch (primary)

```text
Using the FACT SHEET below, draft 7 GBP posts (Day 1–7). Each post:
- 400–900 characters preferred (ok to note if longer)
- 1 clear next step (call / book / reply)
- 3–5 optional photo ideas (no stock-photo claims)
- 1 line CTA without pressure
- [OWNER CHECK] tags where needed

Day themes:
1) Useful how-to / prevention tip for {{trade}}
2) Service-area / what we actually do (no fluff)
3) Seasonal readiness for {{seasonal}}
4) Estimates & how booking works (honest)
5) FAQ teaser that points to Q&A / call
6) Team / standards / show-up practices (no fake awards)
7) Warm review-ask + how to contact (ethical)

FACT SHEET:
{{paste_fact_sheet}}

Also list 5 topics to avoid this week (overselling, unverified claims, etc.).
```

---

## Prompt 3 — Day 1 how-to tip

```text
Write ONE GBP post: practical prevention/how-to for {{trade}} in {{service_area}}.
Audience: homeowners, not technicians.
Include: problem signal, safe DIY boundary, when to call {{business_name}} at {{phone}}.
No scare tactics. Mark medical/gas/electrical danger lines carefully.
FACT bits: {{facts}}
```

---

## Prompt 4 — Day 2 services clarity

```text
Write ONE GBP post that clarifies what {{business_name}} does and does not do.
Services we do: {{do_list}}
Services we do not do: {{dont_list}}
Service area: {{service_area}}
End with how to confirm fit before booking. No keyword stuffing.
```

---

## Prompt 5 — Day 3 seasonal

```text
Write ONE seasonal GBP post for {{seasonal}} relevant to {{trade}}.
Include 3 checklist bullets homeowners can do safely.
State same-day/after-hours ONLY if provided: {{same_day_policy}} / {{after_hours_policy}}
Otherwise use placeholders. CTA to {{phone}} or {{booking_url}}.
```

---

## Prompt 6 — Day 4 estimates & booking

```text
Write ONE GBP post explaining estimates and booking for {{business_name}}.
Estimate process: {{estimate_process}}
Diagnostic fee if any: {{fee_or_none}}
What to have ready when calling: {{prep}}
Be explicit that price depends on on-site findings when true. No bait pricing.
```

---

## Prompt 7 — Day 5 FAQ teaser

```text
Write ONE GBP post that answers one common question briefly and invites more questions via GBP Q&A or phone.
Question: {{question}}
Accurate answer facts: {{answer_facts}}
Keep under ~700 characters if possible. No fake “customers always ask.”
```

---

## Prompt 8 — Day 6 standards / show-up

```text
Write ONE GBP post about how {{business_name}} shows up (arrival window communication, shoe covers, cleanup, written scope — only if true).
True practices: {{practices}}
Do not invent awards, years in business, or “family-owned” unless provided: {{heritage_or_unknown}}.
```

---

## Prompt 9 — Day 7 warm review-ask

```text
Write ONE GBP post inviting happy customers to leave a Google review — ethically.
Rules: optional; no discount/entry for stars; no “only if 5 stars”; no review gating instructions.
Include: thanks, how to find the profile, phone {{phone}} for issues (prefer fixing problems directly).
Business: {{business_name}}. Tone: {{voice}}.
```

---

## Prompt 10 — Q&A bank (12 pairs)

```text
Draft 12 GBP Q&A pairs for {{business_name}} ({{trade}}, {{service_area}}).

Cover: services, area, same-day, after-hours, estimates, warranty, prep before arrival, payments, license/insurance, brands/models, financing, how to request a quote.

Rules from system prompt apply. Answers must use {{placeholders}} for any unverified policy.
For each: Question + Answer + [OWNER CHECK] if needed.
Do not fabricate customer identities. These are owner-published answers to common questions.
```

---

## Prompt 11 — Rewrite in owner voice

```text
Rewrite the following GBP draft in the owner’s voice.

Voice notes: {{voice}}
Banned words: {{bans}}
Keep all facts; do not add new claims.
Draft:
{{draft}}

Return: revised post + list of any claims still needing [OWNER CHECK].
```

---

## Prompt 12 — Shorten for mobile

```text
Shorten this GBP post to ≤ {{max_chars}} characters without losing the CTA or required disclaimer lines.
Post:
{{draft}}
```

---

## Prompt 13 — Owner approval checklist

```text
Create a publish checklist for this week’s GBP content.

Posts:
{{posts}}
Q&A:
{{qa}}

Checklist must include: factual accuracy, license/insurance wording, pricing honesty, no review incentives, no fake UGC, service-area accuracy, phone/URL correct, emergency disclaimer where relevant, owner initials/date line.
Output as markdown checkboxes.
```

---

## Prompt 14 — Adapt trade (quick switch)

```text
Adapt the FACT SHEET and this week’s themes from {{old_trade}} to {{new_trade}} for the same brand voice.
Keep service area {{service_area}} unless changed: {{new_area_or_same}}.
List which posts must be rewritten vs light-touch edits. Do not carry over trade-specific safety claims incorrectly.
```

---

## Day theme cheat sheet

| Day | Theme |
|-----|--------|
| 1 | How-to / prevention |
| 2 | What we do / don’t |
| 3 | Seasonal |
| 4 | Estimates & booking |
| 5 | FAQ teaser |
| 6 | Show-up standards |
| 7 | Warm review-ask |

*Passive Engine · prompt-gbp-7day-home-services-v0.1 · original templates · no ranking or income claims*
