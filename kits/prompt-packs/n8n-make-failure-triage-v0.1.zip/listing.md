# PromptBase listing — n8n/Make Failure Triage Prompt Pack

| Field | Value |
|-------|-------|
| **Title** | n8n/Make Failure Triage Prompt Pack |
| **SKU** | `prompt-n8n-make-triage-v0.1` |
| **PromptBase price** | **$4.99** |
| **BTC zip price** | **$5.99** (pay-btc companion) |
| **Category** | Automation / No-code / Debugging |
| **Model tags** | ChatGPT, Claude, Gemini, GPT-4o, Claude 3.5/4 |
| **File in zip** | `prompts.md` + `README.md` |

## Short description (PromptBase)

14 prompts to triage broken **n8n** and **Make.com** workflows: auth expiry, rate limits, partial success, webhook retries, wrong data mapping, timezone bugs, and dead-letter patterns. Built for freelancers and ops folks who fix automations for a living — not generic “write a Zap” fluff.

## Preview-safe blurb (safe to show unpaid)

> When a client says “the automation broke,” you need a repeatable intake — not vibes. This pack gives you a **failure-triage system prompt** plus playbooks for: 401/403 auth, 429 rate limits, empty arrays after mapping, webhook double-fires, Continue-On-Fail traps, Make scenario incomplete runs, and writing a calm client status update.
>
> Preview shows the triage rubric (layer checklist). Paid file = 14 copy-paste prompts + README.

## What’s included (paid)

- System prompt: automation failure triage lead  
- Intake + evidence checklist prompt  
- Auth / token / OAuth expiry  
- Rate limit / pagination  
- Mapping & null/empty path bugs  
- Webhook retry / idempotency  
- Partial success & Continue On Fail  
- Timezone / schedule drift  
- n8n-specific and Make-specific deep dives  
- Client-facing status + scope boundary replies  
- Postmortem template prompt  

## What this is not

- Not affiliated with n8n GmbH or Make.com  
- Not executable workflow JSON (prompts only)  
- No income guarantees or fake “I made $10k fixing Zaps” stories  

## Suggested PromptBase keywords

`n8n`, `make.com`, `zapier`, `automation`, `webhook`, `workflow debugging`, `ops`, `freelance automation`
