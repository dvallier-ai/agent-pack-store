# n8n / Make Failure Triage — Prompts

Replace placeholders. Redact secrets. One failure per chat thread works best.

---

## Prompt 0 — System: automation triage lead

```text
You are an automation failure-triage lead for n8n and Make.com (and Zapier-shaped flows). Your job is to identify the LAYER and the smallest safe next check.

Layers:
A) Trigger — schedule, webhook, polling gap, missed event
B) Auth — expired OAuth, wrong workspace, revoked key, scope mismatch
C) Upstream data — empty payload, schema change, pagination cut off
D) Mapping/transform — wrong path, type coercion, null branching
E) Downstream API — 4xx/5xx, rate limit, idempotency, partial write
F) Control flow — IF/Switch, Continue On Fail, error branch unused
G) Ops — timezone, DST, duplicate executions, concurrency

Rules:
- Demand evidence: execution id/time, node/module name, status code, raw error snippet (redacted).
- Give ONE next check at a time. Prefer read-only checks before writes.
- Never ask for live API keys, passwords, or customer PII. Accept redacted pastes.
- Separate “broken mapping” from “vendor outage.”
- When writing client text: calm, no blame, no fake certainty, no income/ROI claims.
- If information is insufficient, ask up to 5 targeted questions, then stop.
```

---

## Prompt 1 — Universal intake

```text
Run failure intake for this automation.

Platform: {{n8n | Make | Zapier-like}}
Workflow/scenario name: {{name}}
When it last succeeded: {{datetime_tz}}
When it failed: {{datetime_tz}}
Trigger type: {{webhook | schedule | app-event | manual}}
Failed node/module: {{name}}
HTTP status if any: {{code}}
Error message (redacted):
{{error}}
What the business expected to happen:
{{expected}}
What actually happened (e.g. none / partial / duplicate):
{{actual}}

Output:
1) Likely layer (A–G) with confidence
2) Top 3 hypotheses ranked
3) Evidence still needed (max 5 bullets)
4) ONE read-only next check
```

---

## Prompt 2 — Auth / OAuth / 401 / 403

```text
Suspected auth failure.

Platform: {{n8n|Make}}
App/connection name: {{app}}
Error: {{401_403_or_message}}
Token/connection last refreshed: {{date_or_unknown}}
Scopes required for this action: {{scopes_or_unknown}}
Did a different workflow using the same connection succeed today?: {{yes_no}}

Triage auth vs scope vs wrong environment (prod/sandbox). Give a reconnect checklist and ONE verification request that proves auth without writing customer data.
```

---

## Prompt 3 — Rate limit / 429 / throttling

```text
Runs fail with 429 or intermittent throttle.

- Vendor: {{api}}
- Burst pattern: {{how_many_per_minute}}
- Pagination used?: {{yes_no}}
- Retry/backoff configured?: {{describe}}
- Batch size: {{n}}

Propose a backoff + jitter approach and a throughput cap for {{platform}}. Include how to distinguish hard quota vs short spike. ONE config change to try first. No “just buy enterprise” as the only answer unless evidence says so.
```

---

## Prompt 4 — Mapping / empty array / null path

```text
Node succeeds but later steps get empty/null values.

Sample input item (redacted JSON):
{{json}}
Expression/mapping used:
{{expression}}
Expected field path:
{{path}}
Actual runtime value type:
{{type_or_empty}}

Explain likely path/type bug. Show a corrected mapping sketch. Add a guard (IF/Filter) so empty data fails loudly instead of writing blank records. Keep examples minimal.
```

---

## Prompt 5 — Webhook double-fire / retries / idempotency

```text
Webhook-triggered flow creates duplicates or misses events.

- Sender retries?: {{yes_no_unknown}}
- Response status we return to sender: {{code}}
- Dedupe key available (event id)?: {{field_or_none}}
- Concurrent executions allowed?: {{yes_no}}
- Observed symptom: {{duplicate|missed|reordered}}

Design an idempotency approach (store event id, short-circuit). For n8n and Make, describe where to put the check conceptually. Warn about acknowledging too early vs too late. ONE implementation step first.
```

---

## Prompt 6 — Partial success & Continue On Fail

```text
Some items worked; some failed; workflow still shows success (or error swallowed).

Platform: {{n8n|Make}}
Continue On Fail / allow error?: {{yes_no}}
Error branch exists?: {{yes_no}}
Example failed item error:
{{error}}
Downstream side effects already applied:
{{list}}

Explain the danger. Propose error-branch pattern + alerting. Draft a recovery order: what to replay vs what must not double-charge/double-email. ONE immediate config fix.
```

---

## Prompt 7 — Schedule / timezone / DST drift

```text
Scheduled automation fires at the wrong wall-clock time or skipped a day.

- Platform timezone setting: {{tz}}
- Node/module timezone if any: {{tz}}
- Cron / interval: {{expr}}
- Owner expected time: {{local_expectation}}
- Recent DST change?: {{yes_no}}

Diagnose timezone layer. Give a verification method using the next three fire times. ONE setting to align. Avoid blaming “the cloud” without evidence.
```

---

## Prompt 8 — Pagination / incomplete sync

```text
Sync job “succeeds” but downstream counts are short.

- Endpoint: {{name}}
- Page size: {{n}}
- Next-page field: {{field}}
- Stop condition used: {{describe}}
- Expected count vs got: {{expected}} vs {{got}}

Find off-by-one / early-stop / missing cursor bugs. Outline a safe pagination loop checklist. ONE logging field to add to prove completeness.
```

---

## Prompt 9 — n8n-specific deep dive

```text
Platform is n8n.

Workflow notes:
- Version/sharing: {{cloud|self-host}}
- Execution mode: {{regular|queue}}
- Problematic node type: {{node}}
- Expression (redacted): {{expr}}
- Binary data involved?: {{yes_no}}
- Error workflow linked?: {{yes_no}}

Ask any missing n8n-specific questions (max 4), then propose a fix plan with node-level steps. Mention Pin Data / mock only if useful for safe replay. No claim of access to my instance.
```

---

## Prompt 10 — Make.com-specific deep dive

```text
Platform is Make (Integromat).

Scenario notes:
- Modules around failure: {{list}}
- Incomplete executions?: {{yes_no}}
- Directives used (ignore/break/commit)?: {{list}}
- Array aggregator/iterator in play?: {{yes_no}}
- Error handler route?: {{yes_no}}
- Error:
{{error}}

Triage using Make concepts (bundles, incomplete executions, directives). Propose ONE module-level change and how to replay safely without duplicating side effects.
```

---

## Prompt 11 — Vendor schema change

```text
Automation broke after an upstream app update; fields renamed or types changed.

- App: {{app}}
- Field that disappeared/changed: {{field}}
- Sample old vs new payload if known:
OLD: {{old}}
NEW: {{new}}
- Hard-coded mappings: {{list}}

Produce a schema-diff checklist and a temporary adapter mapping. Suggest a contract test (sample fixture) so the next change is caught earlier. Calm tone; no drama.
```

---

## Prompt 12 — Client status update (no blame)

```text
Write a short client update (email or Slack) about this automation failure.

Facts only:
- Layer: {{layer}}
- Impact: {{what_broke_for_users}}
- Fix in progress: {{steps}}
- ETA style: {{range_or_next_update_time}} — do not invent precision
- What I need from client: {{ask_or_none}}

Constraints: no fake apologies theater, no guaranteed ROI, no blaming the client’s staff, no promising refunds unless I said to. Max 120 words. Offer one clear next step.
```

---

## Prompt 13 — Scope boundary (out of contract)

```text
Help me reply when the “fix” is actually a new build.

Original scope:
{{scope}}
New request discovered during triage:
{{new_request}}
Time already spent diagnosing: {{hours}}

Draft a firm, polite boundary: what is covered as repair vs what needs a change order. Include a ballpark structure like “estimate after 30-min discovery” without inventing a dollar amount unless I provide one: {{optional_price}}.
```

---

## Prompt 14 — Postmortem (internal)

```text
Create a 1-page postmortem for this automation incident.

- Incident summary: {{summary}}
- Root cause layer: {{layer}}
- Detection gap: {{how_we_noticed_late}}
- Fix applied: {{fix}}
- Prevention: monitoring, alert, test, runbook line

Output markdown with sections: Summary, Impact, Cause, Fix, Prevention, Follow-ups. No customer names if not provided. No hero narrative.
```

---

## Quick map

| Symptom | Prompt |
|---------|--------|
| Unknown | 1 |
| 401/403 | 2 |
| 429 | 3 |
| Empty fields | 4 |
| Duplicates | 5 |
| Swallowed errors | 6 |
| Wrong time | 7 |
| Short sync | 8 |
| n8n details | 9 |
| Make details | 10 |
| Schema change | 11 |
| Client update | 12–13 |
| Closeout | 14 |

*Passive Engine · prompt-n8n-make-triage-v0.1 · original templates · no earnings claims*
