# n8n/Make Failure Triage Prompt Pack — Buyer README

**Version:** 0.1.0 · **Seller:** Dan Vallier / Passive Engine · Agent Pack Store  
**Use with:** ChatGPT, Claude, Gemini (cloud models work best for long error pastes)

## What you bought

Prompts that force structured triage of broken n8n and Make (Integromat) scenarios: evidence → layer → fix hypothesis → client-safe update.

## How to use

1. Paste **Prompt 0** as system / custom instructions for the chat session.
2. Run **Prompt 1 (intake)** with redacted screenshots described in text, error JSON, and node/module names.
3. Jump to the matching symptom prompt (auth, rate limit, mapping, webhook, etc.).
4. Use **Prompt 12–13** for client communication after you know the layer.
5. Close with **Prompt 14** postmortem so the same failure is less likely next week.

## Redaction rules (do this every time)

Before pasting into any LLM:

- Strip API keys, tokens, webhook secrets, customer emails/phones, invoice amounts if sensitive  
- Replace with `{{REDACTED_KEY}}`, `{{customer_id}}`, etc.  
- Keep error **codes**, node names, and field **paths** — those are what triage needs  

## Platform notes

- Prompts cover **n8n** and **Make**; Zapier-shaped failures often map to the same layers.  
- The model does not have live access to your instance unless you connect tools yourself.  
- Prefer pasting execution JSON / module output over vague “it doesn’t work.”

## License (buyer)

Use in your freelance/client work freely. Do not resell this pack as a prompt product.

## Support

SKU `prompt-n8n-make-triage-v0.1` · fulfill contact on your receipt / `dvallier@gmail.com` for crypto orders.
