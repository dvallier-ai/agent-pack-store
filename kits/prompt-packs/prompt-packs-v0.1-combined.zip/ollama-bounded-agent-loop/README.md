# Ollama Bounded Agent Loop — System & Tool-Use Prompt Pack v0.1

**Seller:** Dan Vallier / Passive Engine · Agent Pack Store  
**SKU:** `prompt-ollama-bounded-agent-loop-v0.1`  
**PromptBase:** $9.99 · **BTC/ETH zip:** $9.99

Educational copy-paste prompts for keeping local Ollama agent loops **bounded**. Distilled from the Ollama agent-loops course + debugger companion patterns.

## How to use

1. Paste **Prompt 0 (system)** into your harness or Custom Instructions.
2. Use tool-policy / stop / observation prompts when designing the loop.
3. Run stub exercises (echo/clock) before any shell tool.
4. Prefer localhost Ollama; do not bind `0.0.0.0` without auth.

## Honesty

- Not affiliated with Ollama.
- Prompts will not overcome OOM, a downed `ollama serve`, or missing stop counters in code.
- No income claims.

## Support

`dvallier@gmail.com` · include SKU `prompt-ollama-bounded-agent-loop-v0.1`

---
*Passive Engine · educational templates · 2026-09-19 PT*
