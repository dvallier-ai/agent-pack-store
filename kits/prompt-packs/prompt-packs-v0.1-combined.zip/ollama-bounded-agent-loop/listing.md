# PromptBase listing — Ollama Bounded Agent Loop — System & Tool-Use Prompt Pack

| Field | Value |
|-------|-------|
| **Title** | Ollama Bounded Agent Loop — System & Tool-Use Prompt Pack |
| **SKU** | `prompt-ollama-bounded-agent-loop-v0.1` |
| **PromptBase price** | **$9.99** |
| **BTC zip price** | **$9.99** (pay-btc companion) |
| **Category** | Coding / AI Agents / Local LLM |
| **Model tags** | ChatGPT, Claude, Gemini, Llama, Mistral, Ollama, Local LLM |
| **File in zip** | `prompts.md` + `README.md` |

## Short description (PromptBase)

System + tool-use prompts that keep a **local Ollama agent loop bounded**: allowlists, max turns / tool budgets, observation hygiene, and clean stop rules. Distilled for builders shipping stub loops (echo/clock/read) before adding shell tools. Educational templates — not a hosted agent.

## Preview-safe blurb (safe to show unpaid)

> Want an Ollama agent that **stops** instead of spinning forever? This pack gives you a bounded system prompt, tool-policy blocks, observation formats (OK/ERR), stop-condition drills, and harness-design prompts (MAX_TURNS, MAX_TOOL_CALLS, duplicate-call guards). Built for localhost Ollama — no cloud agent hype.
>
> Preview = system outline + one stop drill. Paid = full prompt set + buyer README.

## What’s included (paid)

- 1 system prompt: bounded local agent (allowlist + stop rules)
- Tool-policy + observation hygiene prompts
- Stop-condition and budget prompts (turns / tool calls / wall clock)
- Stub tool exercise prompts (echo / clock / force allowlist failure)
- Harness checklist prompt (what to log before claiming “it works”)
- Buyer README with paste order and honesty limits

## What this is not

- Not affiliated with Ollama
- Not a substitute for fixing RAM/bind/timeouts in code
- No income claims, fake case studies, or “make money with AI agents”

## Suggested PromptBase keywords

`ollama`, `local llm`, `agent loop`, `tool use`, `system prompt`, `stop conditions`, `allowlist`, `AI agent`, `llama.cpp`
