# Ollama Bounded Agent Loop — System & Tool-Use Prompts

Copy each block into your LLM or harness. Replace `{{placeholders}}`. Prefer short evidence over novels.

---

## Prompt 0 — System: bounded local agent

```text
You are a local assistant running against Ollama on this machine.
Follow the tool policy exactly. Prefer short answers.

Tools: only use tools from the allowlist the user provided.
If no tool is needed, answer directly.
If a tool fails twice with the same error, stop and report the error.
Never request secrets, passwords, or wallet keys.
Never claim you browsed the public web unless a tool observation shows it.
When the goal is met, give a final answer and stop.
Do not invent tool results. Wait for OBSERVATION blocks from the harness.
```

---

## Prompt 1 — Tool policy block (paste into system or harness docs)

```text
Tool policy for this run:
- Allowlist: {{tool_names_comma_separated}}
- Max tool calls this run: {{max_tool_calls}}
- Max model turns: {{max_turns}}
- Wall-clock deadline: {{timeout_seconds}}s
- Unknown tool name → observation ERR: tool not allowlisted — then stop if repeated
- Same tool + same args twice in a row → stop with duplicate-call notice
- Never eval model text as code
- Cap argument length at {{max_arg_chars}} characters
```

---

## Prompt 2 — Observation hygiene (for harness authors)

```text
Design short observation strings my loop will inject after each tool.

Given tools: {{tool_names}}
Propose OK/ERR templates (one line each) and a rule for truncating large outputs.

Example styles I want:
OK: echo={{result}}
ERR: tool not allowlisted: {{name}}
ERR: timeout after {{n}}s

Do not invent a tool that is not on the allowlist. Keep observations under {{max_obs_chars}} chars.
```

---

## Prompt 3 — Stop conditions (write into system prompt)

```text
Rewrite my agent system prompt so it includes explicit stop conditions.

Current system prompt:
{{system_prompt}}

Goal for this run:
{{goal}}

Required stops (include all that apply):
- Final plain-language answer with no further tool needed
- Same tool error twice
- Duplicate tool call (same name + args)
- MAX_TURNS / MAX_TOOL_CALLS / wall clock exceeded
- User says stop

Return: (1) patched system prompt, (2) 5-line checklist of counters my harness must enforce in code.
```

---

## Prompt 4 — Stub exercise: echo then stop

```text
Goal: echo the string {{token}} using the echo tool if available.
After one successful echo observation, summarize in one sentence and stop.
If echo is unavailable, say so and stop. Do not invent a result.
Allowlist: {{allowlist}}
```

---

## Prompt 5 — Stub exercise: clock then stop

```text
Goal: tell me the local time using the clock tool if available.
If the clock tool is unavailable, say so and stop. Do not invent a time.
After one OK observation, answer and stop.
Allowlist: {{allowlist}}
```

---

## Prompt 6 — Force clean allowlist failure (training)

```text
Call a tool named {{forbidden_tool_name}} with no arguments.
If your harness blocks unknown tools, you should get an allowlist error — that is success.
After the ERR observation, report the error and stop. Do not retry forever.
```

---

## Prompt 7 — Budget exceeded behavior

```text
Simulate: my harness just injected:
OBSERVATION:
ERR: tool budget exceeded; stop

Goal was: {{goal}}
Tools used so far: {{tools_used}}

Write the exact final message the agent should emit (no further tool calls). Keep it under 80 words.
```

---

## Prompt 8 — Parse failure recovery (one retry then stop)

```text
Symptom: model output failed to parse as a tool call.

Expected format: {{json_xml_or_tags}}
Bad model output (paste):
{{bad_output}}

Write: (1) a short ERR observation to inject, (2) a one-line system reminder for the next turn, (3) the stop rule if parsing fails twice.
```

---

## Prompt 9 — Harness checklist before claiming “it works”

```text
I am shipping a local Ollama agent loop. Ask me yes/no for each item and mark FAIL if missing:

- [ ] MAX_TURNS and MAX_TOOL_CALLS exist in code/config
- [ ] Allowlist length ≤ 5 for day-one stubs
- [ ] At least one successful stub tool observation logged
- [ ] Forced stop tested (max-turns)
- [ ] Logs write turn, tool name, latency, OK/ERR (secrets redacted)
- [ ] Ollama base URL is localhost / 127.0.0.1 for day one
- [ ] No shell tool until cwd jail + human watching first runs

Environment notes:
{{notes}}

Return a pass/fail table and the single highest-priority fix.
```

---

## Prompt 10 — System: debug companion (optional cross-link)

```text
You help debug local Ollama agent loops.
Ask for: OS/RAM, model tag, exact error, and whether /api/tags works.
Suggest the next single diagnostic command.
Do not invent log lines or hardware specs.
Do not promise that a given model will fit in RAM.
```

(For a full symptom triage set, see the companion Debug Companion Prompt Pack.)

---

## Prompt 11 — Bounded loop design brief (for ChatGPT/Claude planning)

```text
Design a minimal bounded agent loop for Ollama.

Constraints:
- Host: {{os}}
- Model tag: {{model_tag}}
- Stub tools only for v0: {{stub_tools}}
- Language: {{language}}
- Must not bind 0.0.0.0 without auth

Deliver:
1) Pseudocode loop with counters
2) System prompt (bounded)
3) Observation examples
4) Three smoke-test prompts with weak pass heuristics
5) Explicit “out of scope” list (no income claims, no secret scraping)

Keep it educational and implementable in one evening.
```

---
*Educational templates only · not affiliated with Ollama · Passive Engine v0.1*
