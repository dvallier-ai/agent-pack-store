# Local LLM / Ollama Debug Companion Prompt Pack Prompts — Buyer README

**Version:** 0.1.0 · **Seller:** Dan Vallier / Passive Engine · Agent Pack Store  
**Use with:** ChatGPT, Claude, Gemini, or any local chat UI pointed at Ollama  

## What you bought

A focused prompt pack that turns an LLM into a **symptom → layer → next command** debugger for local Ollama agent loops (model + tools + stop condition).

## How to use (5 minutes)

1. Open `prompts.md`.
2. Paste **Prompt 0 (system)** into your assistant’s system / custom instructions field (or as the first message if you have no system slot).
3. When something breaks, pick the matching **symptom prompt** (1–8). Fill every `{{placeholder}}` with real evidence — do not invent logs.
4. Run the **single** diagnostic the model suggests. Paste the result back. Repeat once.
5. Use Prompts 9–10 when designing the harness; Prompt 11 to practice deliberate failure.

## Paste order that works

1. System (Prompt 0)  
2. Your environment block (OS, RAM/VRAM, `ollama --version`, model tag, how you call the API)  
3. Exact error or last 20–40 log lines  
4. One triage prompt  

## Honesty limits

- Prompts cannot fix OOM, a downed `ollama serve`, or missing `MAX_TOOL_CALLS` by themselves.  
- Never paste secrets, API keys, wallet seeds, or production PII into the chat.  
- Not affiliated with Ollama Inc. Educational / productivity templates only.  
- No earnings claims; results depend on your hardware and code.

## License (buyer)

Personal and commercial use of the prompts in your own projects and client work is fine.  
Do **not** resell or republish this pack as a competing prompt product, zip, or PromptBase listing.

## Support

Questions about this zip: email the address on your order receipt / pay page (`dvallier@gmail.com` for crypto fulfill). Include SKU `prompt-ollama-loop-debugger-v0.1`.
