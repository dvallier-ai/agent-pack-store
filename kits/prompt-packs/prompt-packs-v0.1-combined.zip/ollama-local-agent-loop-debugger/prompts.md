# Ollama Local Agent Loop Debugger — Prompts

Copy each block into your LLM. Replace `{{placeholders}}`. Prefer short evidence over novels.

---

## Prompt 0 — System: debug companion (use always)

```text
You are a local Ollama agent-loop debugger. You help humans find which LAYER failed and what ONE command or code check to run next.

Layers (pick one per turn):
1) Runner/API — ollama serve, bind host, /api/tags, model pull
2) Capacity — RAM/VRAM, quant size, context length, parallel models
3) Loop control — max turns, wall clock, duplicate tool calls, stop rules
4) Tooling — allowlist, parse errors, empty/ERR observations, timeouts
5) Environment — wrong localhost (Docker/WSL), env vars, cwd
6) Eval — flaky fixtures, non-deterministic tools, missing assertions

Rules:
- Ask for missing evidence: OS/RAM, model tag, exact error, whether curl http://127.0.0.1:11434/api/tags works.
- Suggest exactly ONE next diagnostic (command or 3-line code check). Wait for the result.
- Never invent log lines, hardware specs, or claim a model fits in RAM.
- Never request secrets, passwords, wallet keys, or production credentials.
- Prefer localhost-only Ollama; warn if user proposes binding 0.0.0.0 without auth.
- If the goal is met, summarize: layer, root cause, fix, and stop.
- Be concise. Tables are fine. No motivational filler.
```

---

## Prompt 1 — Connection refused / API down

```text
Symptom: Ollama agent cannot reach the API (connection refused / timeout).

Environment:
- OS: {{os}}
- How I start Ollama: {{serve_command_or_app}}
- Client base URL: {{base_url}}
- Exact error: {{error}}
- Result of: curl -sS -m 5 http://127.0.0.1:11434/api/tags
  {{tags_result_or_error}}

Using the debug companion rules: name the layer, list the top 3 likely causes ranked, then give ONE next command only.
```

---

## Prompt 2 — Model not found / wrong tag

```text
Symptom: agent or client says model not found / 404 on generate/chat.

- Intended model tag: {{model_tag}}
- OLLAMA_MODEL / config value: {{config_value}}
- Output of `ollama list` (paste):
{{ollama_list}}
- Exact client request JSON (redact secrets):
{{request_json}}

Diagnose tag mismatch vs not pulled vs wrong API path. Give ONE next command (pull, rename, or config fix). Do not invent that a model exists.
```

---

## Prompt 3 — OOM / exit 137 / process killed

```text
Symptom: Ollama or agent process dies with OOM / exit 137 / “killed”.

- Machine RAM / VRAM: {{ram_vram}}
- Model tag + approx size if known: {{model}}
- Context / num_ctx if set: {{num_ctx}}
- Other heavy apps open?: {{yes_no_details}}
- Multiple models loaded?: {{yes_no}}
- Exact message:
{{error}}

Map this to the Capacity layer. Propose a smaller-model or context-cap experiment. Give ONE change to try first. Do not promise the model will fit.
```

---

## Prompt 4 — Silent death loop (alive but no progress)

```text
Symptom: agent keeps running (tokens/tools) but never finishes the goal.

Goal stated to the agent:
{{goal}}

Harness limits I have today:
- max tool calls: {{max_tool_calls_or_none}}
- max turns: {{max_turns_or_none}}
- wall-clock timeout: {{timeout_or_none}}

Last 5 tool call names + short observation (OK/ERR):
1. {{t1}}
2. {{t2}}
3. {{t3}}
4. {{t4}}
5. {{t5}}

System stop rules (paste if any):
{{stop_rules}}

Identify whether this is missing counters, duplicate calls, empty observations, or weak stop rules. Propose ONE harness or prompt change. Do not suggest “just try a bigger model” first.
```

---

## Prompt 5 — Tool parse / allowlist / empty observation

```text
Symptom: tools never fire, fire with bad args, or observations look empty and the model invents success.

- Tool format expected by harness (JSON / XML / tags): {{format}}
- Allowlist: {{tools}}
- Example model output that failed to parse:
{{raw_model_output}}
- What the harness injected as OBSERVATION (if any):
{{observation}}

Pin the failure to parsing vs allowlist vs observation injection. Give ONE concrete fix (parser rule, ERR: prefix, or prompt schema line). Include a 5-line example observation format.
```

---

## Prompt 6 — Duplicate tool spam

```text
Symptom: the same tool is called repeatedly with the same args.

- Tool name: {{tool}}
- Args hash or args: {{args}}
- How many repeats before stop: {{n}}
- Does the observation change between calls?: {{yes_no}}
- Current duplicate detection: {{none_or_describe}}

Design a minimal duplicate-detection rule and a system-prompt sentence that forces stop after 2 identical failures. Output: (1) rule in plain English, (2) 4-line pseudocode, (3) one system-prompt sentence.
```

---

## Prompt 7 — Works in terminal A, fails in B (env drift)

```text
Symptom: `ollama` / curl works in one shell or machine context but the agent fails in another.

Context A (works):
- cwd: {{cwd_a}}
- OLLAMA_HOST: {{host_a}}
- PATH snippet: {{path_a}}

Context B (fails):
- cwd: {{cwd_b}}
- OLLAMA_HOST: {{host_b}}
- How agent is launched: {{launch_b}}
- Error: {{error}}

Compare env drift (Docker vs host, WSL vs Windows, IDE terminal vs systemd). Give ONE command that prints the decisive difference.
```

---

## Prompt 8 — Docker / WSL / “wrong localhost”

```text
Symptom: agent in Docker/WSL cannot reach Ollama on the host (or vice versa).

- Where Ollama runs: {{host_or_container}}
- Where agent runs: {{host_or_container}}
- URLs tried: {{urls}}
- OS: {{os}}
- Exact error: {{error}}

Explain which localhost is which. Recommend a safe URL pattern. Warn against exposing Ollama on 0.0.0.0 without auth. Give ONE next connectivity test.
```

---

## Prompt 9 — Design stop conditions (harness)

```text
I am writing a local agent loop (Ollama + tools). Help me define stop conditions.

Goal type: {{goal_type_e_g_answer_or_file_edit}}
Tools allowlist: {{tools}}
Hard limits I will accept: max_turns={{n}}, max_tool_calls={{m}}, wall_seconds={{s}}

Produce:
1) A system-prompt block (≤12 lines) enforcing stops and “report error after 2 identical tool failures”
2) A checklist of harness counters to implement
3) Three unit-test style scenarios (success, tool ERR, max turns)

Do not include network browse tools unless I listed them. No secrets.
```

---

## Prompt 10 — Observation format + eval fixture

```text
Help me standardize tool observations and one smoke eval for a local Ollama agent.

Tools: {{tools}}
Language/runtime: {{language}}

Give:
1) OBSERVATION templates for OK and ERR (plain text)
2) Truncation rule with a clear `…[truncated]` marker and max chars = {{max_chars}}
3) One headless eval case: prompt, expected keyword or non-empty rule, latency budget {{ms}}ms
4) What NOT to put in evals (live web, nondeterministic clock without freeze, secrets)

Keep it implementable in under an hour.
```

---

## Prompt 11 — Reproduce failure on purpose (training)

```text
I want to practice debugging by breaking my Ollama agent loop ON PURPOSE, then fixing it.

My stack: {{stack_one_line}}

Propose THREE safe, reversible breakages (wrong model tag; missing max turns; empty observation injection). For each: how to break, expected symptom, how to verify the fix. No destructive filesystem or network exposure. No 0.0.0.0 bind.
```

---

## Prompt 12 — Full triage intake (when you are lost)

```text
I am stuck. Run a structured intake, then pick the top layer.

Fill what I know; ask ONLY for missing critical fields; then give ONE next step.

Known:
- Goal: {{goal}}
- Model: {{model}}
- OS/RAM: {{os_ram}}
- /api/tags works?: {{yes_no}}
- Error or last log:
{{log}}
- Limits: turns={{turns}} tools={{tools}} timeout={{timeout}}

Output format:
Layer: …
Confidence: high/med/low
Why: …
ONE next diagnostic: …
Do-not-do-yet: …
```

---

## Quick reference — symptom → start with

| Symptom | Start prompt |
|---------|--------------|
| Connection refused | 1 |
| Model not found | 2 |
| OOM / 137 | 3 |
| Runs forever | 4 or 6 |
| Tools weird / empty | 5 |
| Terminal mismatch | 7 or 8 |
| Designing harness | 9–10 |
| Totally lost | 12 |

*Passive Engine · prompt-ollama-loop-debugger-v0.1 · original templates · no earnings claims*
