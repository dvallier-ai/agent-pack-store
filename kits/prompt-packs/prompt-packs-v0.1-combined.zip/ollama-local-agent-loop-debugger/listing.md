# PromptBase listing — Local LLM / Ollama Debug Companion Prompt Pack

| Field | Value |
|-------|-------|
| **Title** | Local LLM / Ollama Debug Companion Prompt Pack |
| **SKU** | `prompt-ollama-loop-debugger-v0.1` |
| **PromptBase price** | **$5.99** |
| **BTC zip price** | **$6.99** (pay-btc companion) |
| **Category** | Coding / AI Agents / Debugging |
| **Model tags** | ChatGPT, Claude, Gemini, Llama, Mistral, Ollama, Local LLM |
| **File in zip** | `prompts.md` + `README.md` |

## Short description (PromptBase)

12 copy-paste prompts that turn ChatGPT/Claude (or a local model) into a **structured debug companion** for Ollama / local-LLM agent loops: OOM, bind/API failures, silent death loops, tool parse errors, and eval flakiness. Symptom → layer → next command.

## Preview-safe blurb (safe to show unpaid)

> Stuck on a local Ollama agent that loops forever, OOMs, or never calls tools correctly? This pack gives you a **debug companion system prompt** plus triage prompts for: connection refused, model-not-found, exit 137, duplicate tool calls, empty observations, and headless eval failures. Each prompt asks for the right evidence and demands a **single next diagnostic**.
>
> Preview includes the debug-companion system prompt outline and one sample triage flow. Full pack = 12 prompts + how-to README.

## What’s included (paid)

- 1 system prompt: bounded local-agent debug companion
- 8 symptom triage prompts (API, OOM, silent loop, tools, env drift, empty replies, WSL/Docker bind, eval flake)
- 2 harness-design prompts (stop conditions + observation format)
- 1 “reproduce on purpose” training prompt
- Buyer README with paste order and honesty limits

## What this is not

- Not affiliated with Ollama
- Not a substitute for fixing RAM/bind/timeouts in code
- No income claims, fake case studies, or “make money with AI agents”

## Suggested PromptBase keywords

`ollama`, `local llm`, `agent loop`, `tool use`, `debugging`, `llama.cpp`, `RAG agent`, `AI agent`, `OOM`, `eval harness`
