# Receipt to Expense Category Prompt Pack v0.1

**SKU:** `prompt-receipt-to-category-v0.1`  
**PromptBase:** $4.99 · **BTC optional:** $5.99

Read `DISCLAIMER.md` first. Templates only — **not tax advice, not a CPA service**.

## Contents

- `prompts.md` — system + user blocks, variables, example I/O, verify checklist
- `DISCLAIMER.md` — required honesty

## Support

`dvallier@gmail.com` · SKU `prompt-receipt-to-category-v0.1`
