# PromptBase listing — Receipt to Expense Category Prompt (Solopreneur Books)

| Field | Value |
|-------|-------|
| **Title** | Receipt to Expense Category Prompt (Solopreneur Books) |
| **SKU** | `prompt-receipt-to-category-v0.1` |
| **PromptBase price** | **$4.99** |
| **BTC zip price** | **$5.99** (optional companion) |
| **Category** | Productivity / Business |
| **Model tags** | ChatGPT, Claude |
| **File in zip** | `prompts.md` + `DISCLAIMER.md` + `README.md` |

## Short description (PromptBase)

Turn messy receipt memos and bank lines into a **draft category table** for DIY solopreneur books. Paste your chart of accounts (or use the included default menu), get suggested category + confidence + a verify checklist per line. **Not tax advice. Not a CPA product.**

## Preview-safe blurb

> Paste bank lines like `ADOBE *CREATIVE CLOUD $59.99` and get a markdown table: suggested_category, confidence, notes, and a short verify_checklist. Ambiguous lines are forced to `needs_review`.
>
> Includes system + user prompt blocks, variables, and an example I/O. You must verify every suggestion before posting to QuickBooks/Wave/sheets.

## Honesty footer

- Not affiliated with Intuit/QuickBooks, Wave, or any tax authority
- **Not tax advice. Not a CPA service.** Templates only
- No deduction guarantees, audit promises, or income claims
- Redact card numbers, tax IDs, and credentials before pasting into ChatGPT
