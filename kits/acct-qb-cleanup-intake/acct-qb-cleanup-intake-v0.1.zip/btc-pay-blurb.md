# BTC pay-page blurb — Accounting micro SKU

**Status:** Copy stub for pay-btc catalog later. Do not wire payment until fulfill path is ready.

---

## Primary BTC SKU (pick locked)

| Field | Value |
|-------|-------|
| **Name** | Async QuickBooks Cleanup Intake |
| **Price** | **$49 USD** (pay in BTC at spot on checkout) |
| **SKU** | `acct-qb-cleanup-intake-v0.1` |
| **Fulfillment** | Async — human returns a prioritized cleanup list (not live books) |
| **Deliverable** | Written prioritized cleanup list (P0/P1/P2) based on client’s **redacted** QuickBooks export screenshots + short DIY next steps |
| **Turnaround target** | 3 business days after complete redacted intake received |

### Short blurb (paste on pay-btc)

**Async QuickBooks Cleanup Intake — $49 (BTC)**  
Send redacted QuickBooks screenshots (chart of accounts, For Review / register, P&L). Get a prioritized cleanup list and DIY next steps — not full bookkeeping, not tax filing, not a CPA service.  
Include SKU `acct-qb-cleanup-intake-v0.1` in your payment note. Intake form: see pack file `03-quickbooks-cleanup-intake.md` (or link when hosted).

**Disclaimer line (required under the button):**  
*Not tax advice. Not a CPA. You remain responsible for your books and filings.*

---

## Alternate digital SKU (not primary — park for later)

| Field | Value |
|-------|-------|
| **Name** | Accounting Micro Pack (templates zip) |
| **Price** | $9 USD in BTC |
| **SKU** | `accounting-micro-v0.1` |
| **Deliverable** | Instant zip: receipt→category prompt, monthly checklist, QB cleanup intake template, disclaimers |

Use the **$49 intake** as the primary pay-btc accounting SKU for now (clear human deliverable, fits $49–$99 band). Add the $9 zip only when auto-fulfill / manual email zip is wired.

---
*Passive Engine · pay-btc copy stub · 2026-09-19 PT*
