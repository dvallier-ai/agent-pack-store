# Async QuickBooks Cleanup Intake — $49

**SKU:** `acct-qb-cleanup-intake`

## What you send
Redacted QuickBooks **exports / screenshots / CSV** (chart of accounts, For Review / register, P&L). Mask account numbers, tax IDs, and customer PII.

## What you NEVER send
- QuickBooks password, bank password, MFA codes, or live admin access
- Full card numbers or SSNs/EINs

## What you get
A written **prioritized cleanup list** (P0/P1/P2) + DIY next steps within ~3 business days after complete redacted intake.

## What this is not
**Not tax advice. Not a CPA service. Not filing or representation.** Templates/education + async list only. You (or your licensed pro) remain responsible for your books.

See `03-quickbooks-cleanup-intake.md` for the intake form.
