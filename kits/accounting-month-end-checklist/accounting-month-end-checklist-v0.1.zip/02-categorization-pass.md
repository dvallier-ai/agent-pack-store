# 02 — Categorization pass

> **Not tax advice. Not a CPA service.** AI suggestions are drafts — **you** verify.

**Month / year:** _______________

## Prep
- [ ] Chart of accounts list handy (or spreadsheet categories)
- [ ] Uncategorized / “For Review” / “Ask my accountant” bucket open
- [ ] Personal vs business rule written in one sentence for myself

## Pass
- [ ] Clear uncategorized under my personal tolerance
- [ ] Split mixed personal+business charges (or mark personal)
- [ ] Match processor deposits to sales (don’t double-count payouts + gross sales)
- [ ] Transfers between own accounts labeled as transfers — not income/expense
- [ ] Owner draws / contributions labeled correctly
- [ ] Optional: run receipt→category prompt, then **verify every suggestion**

## Ambiguity bin
- [ ] Meals / entertainment flagged `needs_review` if purpose unclear
- [ ] Fuel / vehicle flagged (method is mine / my pro’s — pack will not pick)
- [ ] Large equipment-looking purchases flagged asset vs expense for pro review if unsure

## Honesty
- [ ] I did **not** treat AI output as final
- [ ] Nothing labeled “deductible” solely because a model said so

---
*Education only · Passive Engine*
