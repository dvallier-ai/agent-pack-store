# 03 — Month-end close steps

> **Not tax advice. Not a CPA service.** You (or your licensed pro) own accuracy.

**Month / year:** _______________ **Tool:** ☐ QBO ☐ Desktop ☐ Wave ☐ Sheet ☐ Other

## 1. Hygiene
- [ ] Backup / export a copy (date-stamp filename)
- [ ] Note last reconcile date per bank/CC: _______________

## 2. Source data
- [ ] Bank CSV/OFX for the month
- [ ] Credit-card CSV for the month
- [ ] Processor payouts if used
- [ ] Receipts folder ready (`01-receipts-inbox.md`)

## 3. Reconcile
- [ ] Primary checking reconciled to statement ending balance
- [ ] Credit card(s) reconciled
- [ ] Investigate unmatched cleared items above my threshold $______
- [ ] Record bank fees / interest shown on statements

## 4. Categorize
- [ ] Complete `02-categorization-pass.md`

## 5. Income sanity
- [ ] Invoices issued or noted why not
- [ ] Payments applied correctly
- [ ] Refunds / chargebacks consistent

## 6. Sales-tax reminder *(checkbox only — not a determination)*
- [ ] I checked **my own** sales-tax / marketplace-facilitator situation for this month  
  _If unsure: ask a licensed pro — this pack will not decide._

## 7. Reports glance (for your eyes — not filing)
- [ ] P&L looks plausible
- [ ] No forever-growing “misc” dumpsters
- [ ] A/R follow-ups noted · A/P next 14 days noted

## 8. Lock
- [ ] Month locked / tab frozen if tool supports it
- [ ] One-paragraph note to future-me: odd items
- [ ] If using a pro: share **redacted** questions only — **never** send live QB/bank passwords for a template or $49 intake SKU

## Done definition
- [ ] Banks reconciled · uncategorized under tolerance · receipts folder exists · AI not treated as final

**Signed (optional):** _______________ **Date:** _______________

---
*Education only · Passive Engine*
