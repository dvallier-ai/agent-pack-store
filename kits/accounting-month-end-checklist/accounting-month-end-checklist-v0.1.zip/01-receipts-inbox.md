# 01 — Receipts inbox checklist

> **Not tax advice. Not a CPA service.** See `DISCLAIMER.md`.

**Month / year:** _______________ **Business:** _______________

## Capture
- [ ] Create folder `receipts/YYYY-MM/`
- [ ] Export or photograph receipts for material expenses this month
- [ ] Download processor payout PDFs/CSVs if used (Stripe / PayPal / Square / Shopify)
- [ ] Note missing receipts to chase (vendor email search OK)

## Redaction before any LLM paste
- [ ] Mask full card numbers (last 4 only if needed)
- [ ] Remove SSN / EIN / home address
- [ ] Remove bank login credentials — **never share passwords/MFA with anyone selling templates**
- [ ] Blur customer PII if not needed for the question

## Done
- [ ] Inbox folder exists and is date-stamped
- [ ] Missing-receipt list written down

---
*Education only · Passive Engine*
