# Accounting Month-End Checklist Pack v0.1

**SKU:** `accounting-month-end-checklist`  
**Shelf / BTC:** **$19** (education templates)  
**Seller:** Dan Vallier / Passive Engine · Agent Pack Store

**Read `DISCLAIMER.md` first.** This pack is checklists and prompt wording only. It is **not** tax advice, **not** a CPA service, **not** bookkeeping representation, and **never** requires sharing bank or QuickBooks logins with the seller.

## What’s inside

| File | What it is |
|------|------------|
| `DISCLAIMER.md` | Not advice / not CPA / user owns their books |
| `01-receipts-inbox.md` | Receipt capture & redaction checklist |
| `02-categorization-pass.md` | Categorization pass + AI-assist rules (verify every line) |
| `03-month-end-close-steps.md` | Month-end close steps (reconcile → lock → note) |
| `04-printable-monthly-checklist.md` | One-page printable monthly checklist |
| `05-optional-prompts.md` | Optional copy-paste prompts (receipt→category companion) |

## Who it’s for

Solopreneurs / side hustles doing DIY books who want a structured month-end routine.

## What’s NOT included

- Tax filing, tax planning, or representation
- Seller access to your QuickBooks, bank, or card logins
- Guaranteed categorization or “IRS-proof” language
- Live bookkeeping or CPA letters

## Support

`dvallier@gmail.com` · include SKU `accounting-month-end-checklist`

---
*Templates only · Passive Engine · 2026-09-19 PT*
