# Changelog — checklist-pack-v0.1

## 0.1 — 2026-09-18 PT
- Initial inventory zip
- Added local LLM setup checklist
- Added SMB review-ask + SMS scripts (home services class)
- README with Notion import notes
- No store listing yet (Dan-gated account)
