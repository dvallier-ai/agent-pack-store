# Checklist Pack v0.1 — Local LLM Setup
**SKU:** Niche digital pack (path #4)  
**Format:** Notion-style markdown checklists (import to Notion via Markdown & CSV)  
**Price stub:** $9–$19 when store account ready · **No store signup this weekend**  
**Version:** 0.1 · 2026-09-18 PT

## What’s inside
| File | Use |
|---|---|
| `01-local-llm-setup-checklist.md` | Hardware → Ollama/LM Studio → first chat → hardening |
| `02-smb-review-ask-scripts.md` | Locksmith/HVAC-class review-ask + SMS scripts (warm use only) |
| `CHANGELOG.md` | Version notes |

## How to import to Notion
1. New Notion page → `/import` → Markdown  
2. Or paste each `.md` into a synced database as a “Checklist” template  
3. Toggle every `- [ ]` into Notion to-do blocks if your importer flattens them

## License / honesty
Personal / internal use. Not affiliated with Ollama, LM Studio, Meta, or Google.  
No revenue claimed. Pack is inventory for later Payhip/Gumroad listing.
