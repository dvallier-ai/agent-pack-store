# ✅ SMB review-ask + SMS scripts (home services)
**Vertical class:** Locksmith / HVAC / plumbing-adjacent local SMB  
**Use:** Warm owners only — **not** cold spam  
**Companion:** Lighter than a full Local Biz Ops kit · pack price stub **$49–$99** if sold alone

---

## A. Pre-flight (owner checklist)
- [ ] Google Business Profile claimed & hours correct
- [ ] Review link shortener ready (bit.ly / qr to GBP review URL)
- [ ] Decide channel mix: **in-person card** + **SMS same day** + **email day 3**
- [ ] Train techs: ask only after job is clearly successful
- [ ] Exclude: angry jobs, warranty disputes, incomplete work

## B. In-person ask (tech script — 20 seconds)
> “If we made this easy today, would you mind tapping this link for a quick Google review? It helps other folks on [street/neighborhood] find us. Totally optional.”

- [ ] Hand QR card / show phone link
- [ ] Do **not** stand over them while they write
- [ ] Thank them either way

## C. Same-day SMS (send ≤3h after job)
**Template — customize brackets**
```
Hi [First Name], it's [Tech] from [Shop]. Thanks for trusting us with the [job type] today.
If we earned it, a 30-second Google review helps neighbors find us:
[short link]
Reply STOP to opt out.
```
- [ ] Merge fields tested on a staff phone
- [ ] STOP language present
- [ ] Send from business number / compliant SMS tool

## D. Day-3 email (if no review yet — soft)
**Subject:** Quick favor for [Shop] in [City]?
```
Hi [First Name],

Hope the [job] is still solid. If you have 30 seconds, a Google review
helps local folks choose a contractor they can trust:

[short link]

No pressure — glad we could help.
— [Owner / Office], [Shop] · [phone]
```
- [ ] One follow-up max (no nag sequence beyond day 7)
- [ ] BCC nobody; one-to-one feel

## E. Negative-feedback escape hatch
If customer hesitates or seems unhappy:
```
Totally fair — want to tell me what we can fix first? You can text me here
or call the shop at [phone]. We'd rather make it right than chase a star.
```
- [ ] Route to owner within 1 business hour
- [ ] Do **not** ask for a review in the same breath as an apology

## F. Weekly owner ritual (15 min)
- [ ] Count new reviews vs jobs completed (conversion %)
- [ ] Reply to **every** new review (good and bad)
- [ ] Screenshot wins for tech huddle (positive reinforcement)
- [ ] Kill any tech who pressure-scores (integrity > volume)

## G. Compliance reminders (high-level, not legal advice)
- [ ] Honor STOP / unsubscribe immediately
- [ ] Don’t incentivize reviews with cash/gifts where prohibited
- [ ] Don’t gatekeep: never filter only 5-star asks in a deceptive way
- [ ] Keep a simple consent note if you SMS marketing beyond transactional

---
*Checklist Pack v0.1 · Passive Engine · 2026-09-18 PT · warm-only*
