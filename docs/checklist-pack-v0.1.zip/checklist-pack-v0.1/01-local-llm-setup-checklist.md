# ✅ Local LLM setup checklist
**Goal:** First useful local chat + one RAG-ish folder Q&A in under an afternoon.  
**Audience:** Indie builder / SMB “techie” on a laptop or mini PC.

---

## A. Hardware reality check
- [ ] Confirm RAM ≥ **16 GB** (32 GB preferred for 7–13B Q4/Q5)
- [ ] Note CPU (Apple Silicon / AMD / Intel) and any GPU VRAM
- [ ] Free disk ≥ **40 GB** for models + embeddings
- [ ] Decide: **CPU-only OK** vs need GPU acceleration
- [ ] Pick primary machine (don’t chase dual-boot day one)

## B. Pick a runner (choose one to start)
- [ ] **Option 1 — Ollama** (CLI + simple API) installed from official site
- [ ] **Option 2 — LM Studio** (GUI) installed from official site
- [ ] Skim license / ToS of chosen runner
- [ ] Confirm `localhost` API responds (Ollama `:11434` or LM Studio local server)

## C. First model pull (keep it small)
- [ ] Pull one **small instruct** model (e.g. 3B–8B class quantized)
- [ ] Pull one **code-oriented** model only if you need coding help
- [ ] Record model name + quant (Q4_K_M / Q5 etc.) in a notes doc
- [ ] Delete failed / unused downloads weekly (disk hygiene)

## D. First useful chat
- [ ] Ask a real work question (rewrite email, summarize notes)
- [ ] Set system prompt: role + tone + “don’t invent citations”
- [ ] Test **temperature 0.2** for factual / **0.7** for brainstorm
- [ ] Save 3 prompts that worked as a personal snippet file

## E. Privacy / hardening (non-negotiable for client data)
- [ ] Confirm **airplane / offline** mode works for sensitive paste
- [ ] Never paste passwords, bank, health, or client PII into cloud UIs
- [ ] Bind API to `127.0.0.1` only (no LAN expose day one)
- [ ] If LAN later: reverse proxy + auth; never raw open port
- [ ] Enable disk encryption on the machine (FileVault / LUKS / BitLocker)

## F. Light “RAG” without a platform
- [ ] Create folder `~/llm-context/project-x/` with 5–20 markdown/PDF notes
- [ ] Use runner’s **doc attach / rag** feature OR a simple script that dumps file text into the prompt
- [ ] Cap context: prefer summaries over dumping entire books
- [ ] Label answers: “from local notes” vs “model guess”

## G. Automation toe-hold (optional same weekend)
- [ ] Curl/HTTP one completion from a script
- [ ] Wire a single n8n/Make HTTP node → local endpoint (localhost caveats on cloud Zaps!)
- [ ] Log latency + tokens for one week (rough notebook)

## H. Done definition
- [ ] Can answer a work question **offline**
- [ ] Know which model file is authoritative
- [ ] Have a one-page “how I run this” note for future-you
- [ ] Park shopping for a $2k GPU until usage proves need

---
*Checklist Pack v0.1 · Passive Engine · 2026-09-18 PT*
